library(exptest)

co.exp.test(x, simulate.p.value=FALSE, nrepl=2000)