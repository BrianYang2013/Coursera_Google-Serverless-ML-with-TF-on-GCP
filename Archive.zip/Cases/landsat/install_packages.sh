#!/bin/bash

apt-get install python-pip python-gdal
pip install google-cloud-dataflow
